import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'node:path';

export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy: { '/api': 'http://127.0.0.1:8787' } },
  build: {
    rollupOptions: {
      input: {
        main: resolve(process.cwd(), 'index.html'),
        cats: resolve(process.cwd(), 'cats/index.html'),
        admin: resolve(process.cwd(), 'admin/index.html'),
        salesAdmin: resolve(process.cwd(), 'admin-sales/index.html'),
        assistant: resolve(process.cwd(), 'assistant/index.html'),
        training: resolve(process.cwd(), 'training/index.html'),
        manuals: resolve(process.cwd(), 'manuals/index.html'),
        guide: resolve(process.cwd(), 'guide/index.html'),
        salesGuide: resolve(process.cwd(), 'guide-sales/index.html'),
      },
    },
  },
});
