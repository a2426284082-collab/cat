import { serviceFailure } from '../../../_lib/service-errors.js';
import { json, requireAdmin, sameOrigin } from '../../../_lib/admin-auth.js';
import { updateSeller } from '../../../_lib/assistant-store.js';
export async function onRequestPatch({env,request,params}){if(!requireAdmin(request,env))return json({success:false,message:'请先登录'},401);if(!sameOrigin(request))return json({success:false,message:'请求来源无效'},403);let body;try{body=await request.json();}catch{return json({success:false,message:'请求格式错误'},400);}try{return json({success:true,data:await updateSeller(env,String(params.recordId),body)});}catch(error){return serviceFailure(error,'更新销售账号失败',502);}}
