import { getCatalog, getVideoChunk, getVideoDownload } from '../../_lib/feishu.js';
import { getTemporaryVideoLink } from '../../_lib/video-links.js';

const CHUNK_SIZE = 4 * 1024 * 1024;

export async function onRequestGet({ env, params, request }) {
  const fileToken = params?.token ?? '';
  if (!/^[A-Za-z0-9_-]{1,200}$/.test(fileToken)) return new Response(null, { status: 404 });
  const range = request?.headers.get('range');
  const match = range ? /^bytes=(\d+)-(\d*)$/.exec(range) : null;
  if (range && !match) return new Response(null, { status: 416 });
  const start = match ? Number(match[1]) : 0;
  const requestedEnd = match?.[2] ? Number(match[2]) : Number.MAX_SAFE_INTEGER;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(requestedEnd) || requestedEnd < start) {
    return new Response(null, { status: 416 });
  }
  const end = Math.min(requestedEnd, start + CHUNK_SIZE - 1);
  try {
    const catalog = await getCatalog(env);
    const type = catalog.videoTokens.get(fileToken);
    if (!type) return new Response(null, { status: 404 });
    if(request&&new URL(request.url).searchParams.get('download')==='1'){
      const file=await getVideoDownload(env,fileToken),ext=type==='video/webm'?'webm':type==='video/mp4'?'mp4':'m4v';
      const name=(new URL(request.url).searchParams.get('name')||'cat-video').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,60)||'cat-video';
      return new Response(file.body,{headers:{'Content-Type':type,'Content-Disposition':`attachment; filename="${name}.${ext}"`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff',...(file.length?{'Content-Length':String(file.length)}:{})}});
    }

    const proxy = env.FEISHU_VIDEO_DELIVERY === 'proxy' ||
      (request?.url && new URL(request.url).searchParams.get('delivery') === 'proxy');
    if (!proxy) {
      const url = await getTemporaryVideoLink(env, fileToken, request?.url);
      if (url) return new Response(null, {
        status: 302,
        headers: {
          Location: url,
          'Cache-Control': 'private, no-store',
          'Referrer-Policy': 'no-referrer',
          'X-Robots-Tag': 'noindex, nofollow',
        },
      });
    }
    const chunk = await getVideoChunk(env, fileToken, start, end, type);
    if (!chunk) return new Response(null, { status: 416 });
    return new Response(chunk.bytes, {
      status: 206,
      headers: {
        'Content-Type': chunk.type,
        'Content-Range': chunk.contentRange,
        'Content-Length': String(chunk.bytes.byteLength),
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'private, max-age=60',
        'X-Content-Type-Options': 'nosniff',
        'X-Robots-Tag': 'noindex',
      },
    });
  } catch {
    return new Response(null, { status: 502, headers: { 'Cache-Control': 'no-store' } });
  }
}
