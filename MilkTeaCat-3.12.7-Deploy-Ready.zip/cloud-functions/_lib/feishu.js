// ADMIN_CONTROL_PATCH_V1
const FEISHU = 'https://open.feishu.cn/open-apis';
const CACHE_MS = 5 * 60 * 1000;

// These caches live only for the lifetime of one function instance. They are an
// optimization; correctness never depends on a shared process or a timer.
let tokenCache = { key: '', value: '', until: 0 };
let catalogCache = { key: '', value: null, until: 0, pending: null };
let adminCatalogCache={key:'',value:null,until:0,pending:null,revision:0};

function config(env) {
  const keys = ['FEISHU_APP_ID', 'FEISHU_APP_SECRET', 'FEISHU_APP_TOKEN', 'FEISHU_TABLE_ID'];
  const missing = keys.filter(key => !env?.[key]);
  if (missing.length) throw Object.assign(new Error('missing configuration'), { code: 'CONFIG_MISSING', missing });
  return env;
}

async function feishuJson(url, options) {
  // Retain only fixed stage labels and numeric upstream codes. Never return or
  // log upstream URLs, messages, request headers, app tokens or credentials.
  const path = new URL(url).pathname;
  const stage = path.includes('/auth/') ? 'auth' : path.includes('/bitable/') ? 'records' : 'media';
  let response;
  try { response = await fetch(url, { ...options, signal: AbortSignal.timeout(12000) }); }
  catch (error) {
    const code = ['TimeoutError', 'AbortError'].includes(error?.name) ? 'FEISHU_TIMEOUT' : 'FEISHU_NETWORK_ERROR';
    throw Object.assign(new Error('Feishu connection failed'), { code, stage });
  }
  if (!response.ok) throw Object.assign(new Error('Feishu HTTP error'), { code: 'FEISHU_HTTP_ERROR', stage, upstreamStatus: response.status });
  let result;
  try { result = await response.json(); }
  catch { throw Object.assign(new Error('Feishu invalid response'), { code: 'FEISHU_INVALID_RESPONSE', stage }); }
  if (result?.code !== 0) throw Object.assign(new Error('Feishu API error'), {
    code: 'FEISHU_API_ERROR', stage,
    ...(Number.isInteger(result?.code) ? { feishuCode: result.code } : {}),
  });
  return result.data ?? result;
}

async function accessToken(env) {
  const key = `${env.FEISHU_APP_ID}:${env.FEISHU_APP_SECRET}`;
  if (tokenCache.key === key && Date.now() < tokenCache.until) return tokenCache.value;
  const result = await feishuJson(`${FEISHU}/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: env.FEISHU_APP_ID, app_secret: env.FEISHU_APP_SECRET }),
  });
  if (!result.tenant_access_token) throw Object.assign(new Error('Feishu token missing'), { code: 'FEISHU_TOKEN_MISSING', stage: 'auth' });
  tokenCache = {
    key,
    value: result.tenant_access_token,
    until: Date.now() + Math.max(0, (Number(result.expire) || 7200) - 300) * 1000,
  };
  return tokenCache.value;
}

function stringValue(value) {
  if (value == null) return '';
  if (Array.isArray(value)) return value.map(stringValue).filter(Boolean).join('');
  if (typeof value === 'object') return stringValue(value.text ?? value.name ?? '');
  return String(value).trim();
}

const VIDEO_TYPES = { mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm' };

function videoAttachments(value) {
  if (!Array.isArray(value)) return [];
  return value.flatMap(item => {
    const name = typeof item?.name === 'string' ? item.name.trim() : '';
    const extension = name.split('.').pop()?.toLowerCase();
    if (!/^[A-Za-z0-9_-]{1,200}$/.test(item?.file_token ?? '') || !VIDEO_TYPES[extension]) return [];
    const displayName = name.length > 120 ? `${name.slice(0, 110)}.${extension}` : name;
    return [{ name: displayName, url: `/api/public-videos/${encodeURIComponent(item.file_token)}` }];
  });
}

function publicCat(record) {
  const fields = record.fields ?? {};
  if (stringValue(fields['状态']) !== '在售') return null;
  const id = stringValue(fields['猫咪ID']);
  if (!id) return null;
  const images = Array.isArray(fields['图片'])
    ? fields['图片'].filter(item => /^[A-Za-z0-9_-]{1,200}$/.test(item?.file_token ?? ''))
      .map(item => `/api/public-images/${encodeURIComponent(item.file_token)}`)
    : [];
  const rawPrice = fields['价格'] == null || stringValue(fields['价格']) === '' ? NaN : Number(fields['价格']);
  return {
    id,
    breed: stringValue(fields['品种']),
    color: stringValue(fields['毛色/花色']),
    gender: stringValue(fields['性别']),
    age: stringValue(fields['年龄']),
    vaccine: stringValue(fields['疫苗']),
    description: stringValue(fields['描述']),
    price: Number.isFinite(rawPrice) && rawPrice >= 0 ? rawPrice : null,
    image: images[0] ?? null,
    images,
    videos: videoAttachments(fields['视频']),
  };
}

async function loadRecords(env) {
  const token = await accessToken(env);
  const url = `${FEISHU}/bitable/v1/apps/${encodeURIComponent(env.FEISHU_APP_TOKEN)}/tables/${encodeURIComponent(env.FEISHU_TABLE_ID)}/records`;
  const items = [];
  let pageToken = '';
  do {
    const pageUrl = new URL(url);
    pageUrl.searchParams.set('page_size', '100');
    if (pageToken) pageUrl.searchParams.set('page_token', pageToken);
    const data = await feishuJson(pageUrl, { headers: { Authorization: `Bearer ${token}` } });
    items.push(...(data.items ?? []));
    if (items.length > 5000) throw new Error('catalog too large');
    pageToken = data.has_more ? data.page_token : '';
    if (data.has_more && !pageToken) throw new Error('pagination token missing');
  } while (pageToken);
  return items;
}

export async function loadTableRecords(envInput, tableId, maximum = 5000) {
  const env = config(envInput);
  if (!tableId) throw new Error('missing table configuration');
  const token = await accessToken(env);
  const base = `${FEISHU}/bitable/v1/apps/${encodeURIComponent(env.FEISHU_APP_TOKEN)}/tables/${encodeURIComponent(tableId)}/records`;
  const items = [];
  let pageToken = '';
  do {
    const url = new URL(base); url.searchParams.set('page_size', '100');
    if (pageToken) url.searchParams.set('page_token', pageToken);
    const data = await feishuJson(url, { headers: { Authorization: `Bearer ${token}` } });
    items.push(...(data.items ?? []));
    if (items.length > maximum) throw new Error('table too large');
    pageToken = data.has_more ? data.page_token : '';
    if (data.has_more && !pageToken) throw new Error('pagination token missing');
  } while (pageToken);
  return items;
}

export async function createTableRecord(envInput, tableId, fields) {
  const env = config(envInput), token = await accessToken(env);
  const url = `${FEISHU}/bitable/v1/apps/${encodeURIComponent(env.FEISHU_APP_TOKEN)}/tables/${encodeURIComponent(tableId)}/records`;
  const data = await feishuJson(url, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }) });
  return data.record;
}

export async function updateTableRecord(envInput, tableId, recordId, fields) {
  const env = config(envInput), token = await accessToken(env);
  const url = `${FEISHU}/bitable/v1/apps/${encodeURIComponent(env.FEISHU_APP_TOKEN)}/tables/${encodeURIComponent(tableId)}/records/${encodeURIComponent(recordId)}`;
  const data = await feishuJson(url, { method: 'PUT', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }) });
  return data.record;
}

async function loadCatalog(env) {
  const items = await loadRecords(env);
  const cats = items.map(publicCat).filter(Boolean);
  return {
    cats,
    imageTokens: new Set(cats.flatMap(cat => cat.images.map(image => image.split('/').pop()))),
    videoTokens: new Map(cats.flatMap(cat => cat.videos.map(video => [video.url.split('/').pop(), VIDEO_TYPES[video.name.split('.').pop().toLowerCase()]]))),
    updatedAt: new Date().toISOString(),
  };
}

function attachmentTokens(value) {
  return Array.isArray(value) ? value.filter(item => /^[A-Za-z0-9_-]{1,200}$/.test(item?.file_token ?? '')).map(item => item.file_token) : [];
}

function numericValue(value) {
  if (value == null || stringValue(value) === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function adminCat(record) {
  const fields = record.fields ?? {}, images = attachmentTokens(fields['图片']);
  return {
    recordId: record.record_id,
    id: stringValue(fields['猫咪ID']),
    status: stringValue(fields['状态']),
    breed: stringValue(fields['品种']),
    color: stringValue(fields['毛色/花色']),
    gender: stringValue(fields['性别']),
    age: numericValue(fields['年龄']),
    vaccine: stringValue(fields['疫苗']),
    description: stringValue(fields['描述']),
    price: numericValue(fields['价格']),
    supplier: stringValue(fields['视频供货商']),
    supplierOriginalId: stringValue(fields['供货商原编号']),
    costPrice: numericValue(fields['进货价']),
    rawDescription: stringValue(fields['原始描述']),
    verificationNote: stringValue(fields['核对备注']),
    image: images[0] ? `/api/admin/images/${encodeURIComponent(images[0])}` : null,
  };
}

export async function getAdminCats(envInput,{fresh=false}={}) {
  const env=config(envInput),key=JSON.stringify([env.FEISHU_APP_ID,env.FEISHU_APP_SECRET,env.FEISHU_APP_TOKEN,env.FEISHU_TABLE_ID]);if(adminCatalogCache.key!==key)adminCatalogCache={key,value:null,until:0,pending:null,revision:0};
  const current=adminCatalogCache;if(!fresh&&current.value&&current.until>Date.now())return current.value;if(current.pending)return current.pending;const revision=current.revision;const job=loadRecords(env).then(rows=>{const data=rows.map(adminCat).filter(cat=>cat.recordId&&cat.id);if(adminCatalogCache===current&&current.revision===revision){current.value=data;current.until=Date.now()+15000;}return data;}).finally(()=>{if(current.pending===job)current.pending=null;});current.pending=job;return job;
}

const textField = (value, maximum) => typeof value === 'string' && value.length <= maximum ? value.trim() : undefined;
const numberField = value => value === '' || value == null ? undefined : Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : null;

export async function updateAdminCat(envInput, recordId, input) {
  const env = config(envInput), fields = {};
  const mappings = [
    ['status','状态',20], ['breed','品种',80], ['color','毛色/花色',80], ['gender','性别',20],
    ['vaccine','疫苗',200], ['description','描述',3000], ['supplier','视频供货商',100],
    ['supplierOriginalId','供货商原编号',100], ['rawDescription','原始描述',5000], ['verificationNote','核对备注',2000],
  ];
  for (const [key, name, maximum] of mappings) {
    if (!(key in (input ?? {}))) continue;
    const value = textField(input[key], maximum);
    if (value === undefined) throw new Error('invalid fields');
    fields[name] = value;
  }
  if (fields['状态'] && !['在售','已售','下架'].includes(fields['状态'])) throw new Error('invalid fields');
  if (fields['性别'] && !['公','母','未知',''].includes(fields['性别'])) throw new Error('invalid fields');
  for (const [key, name] of [['age','年龄'],['price','价格'],['costPrice','进货价']]) {
    if (!(key in (input ?? {}))) continue;
    const value = numberField(input[key]);
    if (value === null) throw new Error('invalid fields');
    if (value !== undefined) fields[name] = value;
  }
  if (!Object.keys(fields).length) throw new Error('invalid fields');
  const token = await accessToken(env);
  const url = `${FEISHU}/bitable/v1/apps/${encodeURIComponent(env.FEISHU_APP_TOKEN)}/tables/${encodeURIComponent(env.FEISHU_TABLE_ID)}/records/${encodeURIComponent(recordId)}`;
  const data = await feishuJson(url, { method: 'PUT', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ fields }) });
  catalogCache = { key: '', value: null, until: 0, pending: null };
  const changed=Object.fromEntries([...mappings.map(([k])=>k),'age','price','costPrice'].filter(k=>Object.hasOwn(input||{},k)).map(k=>[k,input[k]]));
  const cacheKey=JSON.stringify([env.FEISHU_APP_ID,env.FEISHU_APP_SECRET,env.FEISHU_APP_TOKEN,env.FEISHU_TABLE_ID]);if(adminCatalogCache.key===cacheKey){adminCatalogCache.revision++;adminCatalogCache.pending=null;if(adminCatalogCache.value){adminCatalogCache.value=adminCatalogCache.value.map(row=>row.recordId===recordId?{...row,...changed}:row);adminCatalogCache.until=Date.now()+15000;}}
  return adminCat(data.record ?? { record_id: recordId, fields: { ...fields, '猫咪ID': input?.id || '' } });
}

export async function getCatalog(envInput,{fresh=false}={}) {
  const env = config(envInput);
  const key = [env.FEISHU_APP_ID, env.FEISHU_APP_SECRET, env.FEISHU_APP_TOKEN, env.FEISHU_TABLE_ID].join(':');
  if (catalogCache.key !== key) catalogCache = { key, value: null, until: 0, pending: null };
  if (!fresh && catalogCache.value && Date.now() < catalogCache.until) return catalogCache.value;
  if (!catalogCache.pending) {
    catalogCache.pending = loadCatalog(env).then(value => {
      catalogCache.value = value;
      catalogCache.until = Date.now() + CACHE_MS;
      return value;
    }).finally(() => { catalogCache.pending = null; });
  }
  return catalogCache.pending;
}

// Attachment downloads have inconsistent response MIME types on some Feishu uploads.
// Validate unknown MIME by its binary signature; do not reject valid JPEG/WebP etc.
function imageMagic(bytes){
 const b=new Uint8Array(bytes);
 if(b.length>=3&&b[0]===0xff&&b[1]===0xd8&&b[2]===0xff)return 'image/jpeg';
 if(b.length>=8&&[137,80,78,71,13,10,26,10].every((n,i)=>b[i]===n))return 'image/png';
 if(b.length>=6&&String.fromCharCode(...b.slice(0,6)).match(/^GIF8[79]a$/))return 'image/gif';
 if(b.length>=12&&String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP')return 'image/webp';
 if(b.length>=12&&String.fromCharCode(...b.slice(4,8))==='ftyp'&&['avif','avis'].includes(String.fromCharCode(...b.slice(8,12))))return 'image/avif';
 return null;
}
function mediaFailure(code){return Object.assign(new Error('Image source unavailable'),{code});}
export async function getImage(envInput,fileToken){
 const env=config(envInput),token=await accessToken(env);
 let response;
 try{response=await fetch(`${FEISHU}/drive/v1/medias/${encodeURIComponent(fileToken)}/download`,{
  headers:{Authorization:`Bearer ${token}`,'Accept-Encoding':'identity'},
  signal:AbortSignal.timeout(22500),
 });}
 catch(error){throw mediaFailure(['AbortError','TimeoutError'].includes(error?.name)?'IMAGE_TIMEOUT':'IMAGE_NETWORK');}
 if(response.status===404||response.status===410)throw mediaFailure('IMAGE_UPSTREAM_NOT_FOUND');
 if(!response.ok)throw mediaFailure('IMAGE_UPSTREAM_FAILED');
 const length=Number(response.headers.get('content-length'));
 if(length>10*1024*1024)throw mediaFailure('IMAGE_TOO_LARGE');
 let bytes;
 try{bytes=await response.arrayBuffer();}
 catch(error){throw mediaFailure(['AbortError','TimeoutError'].includes(error?.name)?'IMAGE_TIMEOUT':'IMAGE_NETWORK');}
 if(!bytes.byteLength||bytes.byteLength>10*1024*1024)throw mediaFailure('IMAGE_TOO_LARGE');
 const declared=response.headers.get('content-type')?.split(';')[0]?.toLowerCase();
 const allowed=['image/jpeg','image/png','image/webp','image/gif','image/avif'];
 const type=allowed.includes(declared)?declared:imageMagic(bytes);
 if(!type)throw mediaFailure('IMAGE_UNSUPPORTED');
 return{bytes,type};
}

export async function getMediaDownloadLink(envInput, fileToken) {
  const env = config(envInput);
  const token = await accessToken(env);
  const url = new URL(`${FEISHU}/drive/v1/medias/batch_get_tmp_download_url`);
  url.searchParams.append('file_tokens', fileToken);
  const data = await feishuJson(url, { headers: { Authorization: `Bearer ${token}` } });
  const result = data.tmp_download_urls?.find(item => item.file_token === fileToken);
  if (!result?.tmp_download_url) throw new Error('media link unavailable');
  return result.tmp_download_url;
}

export async function getVideoChunk(envInput, fileToken, start, end, type) {
  const env = config(envInput);
  const token = await accessToken(env);
  const response = await fetch(`${FEISHU}/drive/v1/medias/${encodeURIComponent(fileToken)}/download`, {
    headers: { Authorization: `Bearer ${token}`, Range: `bytes=${start}-${end}`, 'Accept-Encoding': 'identity' },
    signal: AbortSignal.timeout(20000),
  });
  if (response.status === 416) return null;
  // Some Feishu media downloads ignore Range and respond with the whole file.
  // Read only the requested window and cancel the upstream stream afterwards.
  if (response.status === 200) {
    const total = Number(response.headers.get('content-length'));
    if (!Number.isSafeInteger(total) || total <= 0 || start >= total || !response.body) {
      if (start >= total && Number.isSafeInteger(total) && total > 0) return null;
      throw new Error('video size unavailable');
    }
    const to = Math.min(end, total - 1);
    const bytes = new Uint8Array(to - start + 1);
    const reader = response.body.getReader();
    let offset = 0;
    try {
      while (offset <= to) {
        const { done, value } = await reader.read();
        if (done) throw new Error('video stream ended early');
        const from = Math.max(start - offset, 0);
        const until = Math.min(to - offset + 1, value.byteLength);
        if (until > from) bytes.set(value.subarray(from, until), offset + from - start);
        offset += value.byteLength;
      }
    } finally {
      await reader.cancel().catch(() => {});
    }
    return { bytes, contentRange: `bytes ${start}-${to}/${total}`, type };
  }
  if (response.status !== 206) throw new Error('Feishu video download error');
  const contentRange = response.headers.get('content-range')?.match(/^bytes (\d+)-(\d+)\/(\d+)$/i);
  if (!contentRange) throw new Error('missing video content range');
  const [, from, to, total] = contentRange.map(Number);
  if (from !== start || to > end || to < from || total <= to || to - from + 1 > 4 * 1024 * 1024) {
    throw new Error('invalid video content range');
  }
  if (Number(response.headers.get('content-length')) > 4 * 1024 * 1024) throw new Error('video chunk too large');
  const bytes = await response.arrayBuffer();
  if (bytes.byteLength !== to - from + 1) throw new Error('video chunk length mismatch');
  return { bytes, contentRange: `bytes ${from}-${to}/${total}`, type };
}

// Full-file download is streamed to the browser; never buffer an entire video in a Worker.
export async function getVideoDownload(envInput,fileToken){
 const env=config(envInput),token=await accessToken(env);
 const response=await fetch(`${FEISHU}/drive/v1/medias/${encodeURIComponent(fileToken)}/download`,{headers:{Authorization:`Bearer ${token}`,'Accept-Encoding':'identity'},signal:AbortSignal.timeout(60000)});
 if(!response.ok||response.status!==200||!response.body){await response.body?.cancel();throw new Error('video download unavailable');}
 const max=200*1024*1024,length=Number(response.headers.get('content-length'));
 if(length>max){await response.body.cancel();throw new Error('video exceeds download limit');}
 let bytes=0;const stream=response.body.pipeThrough(new TransformStream({transform(chunk,controller){bytes+=chunk.byteLength;if(bytes>max)throw new Error('video exceeds download limit');controller.enqueue(chunk);}}));
 return {body:stream,length:Number.isSafeInteger(length)&&length>0?length:null};
}
